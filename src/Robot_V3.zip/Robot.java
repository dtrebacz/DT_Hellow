public interface Robot {
    void checkTemperature();
    void showAttributes();
    void checkStatus();




}
